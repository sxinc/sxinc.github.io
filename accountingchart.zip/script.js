var accountnames = ['Account A','Account B','Account C','Account D','Account E'];
var acctcash = [100,200,300,400,500];
var invest = [1000,2000,3000,4000,5000];
var credits = [111,222,333,444,555];
var ious = [345,456,918,297,282];
var interest = [115,215,315,425,551];

var ctx = document.getElementById("myChart");
var myChart = new Chart(ctx, {
  type: 'bar',
  data: {
    labels: accountnames,
    datasets: [
      { 
        data: acctcash,
        label: "Cash",
        backgroundColor: "rgba(20,40,60,.8)",
     
      },
      {
      	data: invest,
      	label: "Investments",
      	backgroundColor: "rgba(118,0,0,.8)",
      },
      {
      	data: credits,
      	label: "Credits",
      	backgroundColor: "rgba(2,2,2.8)",
      },
      {
      	data: ious,
      	label: "Owings",
      	backgroundColor: "rgba(53,114,102,.8)",
      },
      {
      	data: interest,
      	label: "Interests",
      	backgroundColor: "rgba(163,187,173,.8)",
      }

  			]
  },

  options: {
  scales: {
    xAxes: [{ stacked: true }],
    yAxes: [{ stacked: true }]
  }
}


}
);